#include "types.h"
#include "stat.h"
#include "user.h"
#include "uproc.h"

int main()
{
  struct uproc pcs[64];

  /* call getprocs to prepare for loop */
  int tree = getprocs(64, pcs);   
  
  int i = 0;
  for ( ; i < tree ; i++){
    int ppid = pcs[i].ppid; 

     if(ppid > 0){
      int j = 0;
      for(; j < ppid; ++j)
        printf(1,"   ");
    }//end if loop

    printf(1,"%s[%d]\n", pcs[i].name, pcs[i].pid);  
  }//end for loop

  exit();
}
