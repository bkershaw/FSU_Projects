// Uproc.h

struct uproc {
  int pid;
  int ppid;
  char name[16];
};
